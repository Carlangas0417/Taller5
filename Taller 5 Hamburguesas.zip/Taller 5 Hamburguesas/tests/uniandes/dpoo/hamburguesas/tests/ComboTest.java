package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.Combo;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

public class ComboTest
{
    private Combo combo;
    private ProductoMenu hamburguesa;
    private ProductoMenu papas;
    private ProductoMenu gaseosa;

    @BeforeEach
    void setUp() throws Exception
    {
        hamburguesa = new ProductoMenu("Hamburguesa sencilla", 12000);
        papas = new ProductoMenu("Papas medianas", 5000);
        gaseosa = new ProductoMenu("Gaseosa", 4000);
        ArrayList<ProductoMenu> items = new ArrayList<>();
        items.add(hamburguesa);
        items.add(papas);
        items.add(gaseosa);

        combo = new Combo("Combo sencillo", 0.9, items); // 10% descuento
    }

    @AfterEach
    void tearDown() throws Exception
    {
    }

    @Test
    void testGetNombre()
    {
        assertEquals("Combo sencillo", combo.getNombre());
    }

    @Test
    void testGetPrecio()
    {
        int expected = (int)((12000 + 5000 + 4000) * 0.9);
        assertEquals(expected, combo.getPrecio());
    }

    @Test
    void testGenerarTextoFactura()
    {
        String texto = combo.generarTextoFactura();
        assertTrue(texto.contains("Combo sencillo"));
    }
}
