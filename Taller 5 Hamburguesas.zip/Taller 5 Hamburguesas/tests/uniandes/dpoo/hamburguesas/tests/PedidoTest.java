package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.Pedido;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

public class PedidoTest
{
    private Pedido pedido;
    private ProductoMenu hamburguesa;
    private ProductoMenu papas;

    @BeforeEach
    void setUp() throws Exception
    {
        pedido = new Pedido("Juan Perez", "Calle 123");
        hamburguesa = new ProductoMenu("Hamburguesa sencilla", 12000);
        papas = new ProductoMenu("Papas medianas", 5000);
    }

    @AfterEach
    void tearDown() throws Exception
    {
    }

    @Test
    void testGetIdPedido()
    {
        assertNotNull(pedido.getIdPedido(), "El ID del pedido no debería ser nulo.");
    }

    @Test
    void testGetNombreCliente()
    {
        assertEquals("Juan Perez", pedido.getNombreCliente());
    }

    @Test
    void testAgregarProducto()
    {
        pedido.agregarProducto(hamburguesa);
        pedido.agregarProducto(papas);
        // El precio neto debería ser 12000 + 5000 = 17000
        assertEquals(17000, getPrecioNetoPedido(pedido));
    }

    @Test
    void testGetPrecioTotalPedido()
    {
        pedido.agregarProducto(hamburguesa);
        pedido.agregarProducto(papas);
        int precioNeto = 12000 + 5000; // 17000
        int iva = (int)(precioNeto * 0.19); // 3230
        int precioTotalEsperado = precioNeto + iva; // 20230
        assertEquals(precioTotalEsperado, pedido.getPrecioTotalPedido());
    }

    @Test
    void testGenerarTextoFactura()
    {
        pedido.agregarProducto(hamburguesa);
        pedido.agregarProducto(papas);
        String factura = pedido.generarTextoFactura();
        assertTrue(factura.contains("Juan Perez"));
        assertTrue(factura.contains("Hamburguesa sencilla"));
        assertTrue(factura.contains("Papas medianas"));
        assertTrue(factura.contains("IVA"));
        assertTrue(factura.contains("Precio Total"));
    }

    @Test
    void testGuardarFactura() throws IOException
    {
        pedido.agregarProducto(hamburguesa);
        File tempFile = File.createTempFile("testFactura", ".txt");
        tempFile.deleteOnExit();

        pedido.guardarFactura(tempFile);

        String contenidoFactura = Files.readString(tempFile.toPath());
        assertTrue(contenidoFactura.contains("Juan Perez"));
        assertTrue(contenidoFactura.contains("Hamburguesa sencilla"));
    }

    // Método privado para ayudar a obtener precio neto (porque es privado en Pedido)
    private int getPrecioNetoPedido(Pedido pedido)
    {
        try
        {
            var metodo = Pedido.class.getDeclaredMethod("getPrecioNetoPedido");
            metodo.setAccessible(true);
            return (int) metodo.invoke(pedido);
        }
        catch (Exception e)
        {
            fail("No se pudo acceder a getPrecioNetoPedido.");
            return 0;
        }
    }
}

