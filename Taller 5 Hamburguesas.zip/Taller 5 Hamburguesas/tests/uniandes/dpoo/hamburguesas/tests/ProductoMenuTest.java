package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

public class ProductoMenuTest
{
    private ProductoMenu producto;

    @BeforeEach
    void setUp() throws Exception
    {
        producto = new ProductoMenu("Hamburguesa sencilla", 12000);
    }

    @AfterEach
    void tearDown() throws Exception
    {
    }

    @Test
    void testGetNombre()
    {
        assertEquals("Hamburguesa sencilla", producto.getNombre());
    }

    @Test
    void testGetPrecio()
    {
        assertEquals(12000, producto.getPrecio());
    }

    @Test
    void testGenerarTextoFactura()
    {
        String texto = producto.generarTextoFactura();
        assertTrue(texto.contains("Hamburguesa sencilla"));
        assertTrue(texto.contains("12000"));
    }
}
