package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.io.IOException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.Restaurante;
import uniandes.dpoo.hamburguesas.excepciones.*;

public class RestauranteTest
{
    private Restaurante restaurante;

    @BeforeEach
    void setUp() throws Exception
    {
        restaurante = new Restaurante();
    }

    @AfterEach
    void tearDown() throws Exception
    {
    }

    @Test
    void testCargarInformacionRestaurante() throws HamburguesaException, IOException
    {
        File ingredientes = new File("./data/ingredientes.txt");
        File menu = new File("./data/menu.txt");
        File combos = new File("./data/combos.txt");

        restaurante.cargarInformacionRestaurante(ingredientes, menu, combos);

        assertFalse(restaurante.getIngredientes().isEmpty(), "No se cargaron ingredientes.");
        assertFalse(restaurante.getMenuBase().isEmpty(), "No se cargaron productos base.");
        assertFalse(restaurante.getMenuCombos().isEmpty(), "No se cargaron combos.");
    }

    @Test
    void testIniciarYGuardarPedido() throws HamburguesaException, IOException
    {
    	restaurante.cargarInformacionRestaurante(
    	        new File("./data/ingredientes.txt"),
    	        new File("./data/menu.txt"),
    	        new File("./data/combos.txt")
    	    );
        restaurante.iniciarPedido("Juan Perez", "Calle 123");
        assertNotNull(restaurante.getPedidoEnCurso(), "No se inició el pedido.");

        restaurante.getPedidoEnCurso().agregarProducto(restaurante.getMenuBase().get(0));
        restaurante.cerrarYGuardarPedido();

        assertNull(restaurante.getPedidoEnCurso(), "El pedido no se cerró correctamente.");
    }

    @Test
    void testYaHayUnPedidoEnCursoException() throws HamburguesaException
    {
        restaurante.iniciarPedido("Juan", "Calle 1");
        assertThrows(YaHayUnPedidoEnCursoException.class, () -> {
            restaurante.iniciarPedido("Pedro", "Calle 2");
        });
    }

    @Test
    void testNoHayPedidoEnCursoException()
    {
        assertThrows(NoHayPedidoEnCursoException.class, () -> {
            restaurante.cerrarYGuardarPedido();
        });
    }
}
