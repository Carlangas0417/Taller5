package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;
import uniandes.dpoo.hamburguesas.mundo.ProductoAjustado;
import uniandes.dpoo.hamburguesas.mundo.Ingrediente;

public class ProductoAjustadoTest
{
    private ProductoAjustado productoAjustado;
    private ProductoMenu base;
    private Ingrediente queso;
    private Ingrediente tomate;

    @BeforeEach
    void setUp() throws Exception
    {
        base = new ProductoMenu("Hamburguesa sencilla", 12000);
        productoAjustado = new ProductoAjustado(base);
        queso = new Ingrediente("Queso", 2000);
        tomate = new Ingrediente("Tomate", 1000);
    }

    @AfterEach
    void tearDown() throws Exception
    {
    }

    @Test
    void testGetNombre()
    {
        assertEquals("Hamburguesa sencilla", productoAjustado.getNombre());
    }

    @Test
    void testGetPrecioSinAgregados()
    {
        assertEquals(12000, productoAjustado.getPrecio());
    }

    @Test
    void testGetPrecioConAgregados()
    {
        productoAjustado.agregarIngrediente(queso);
        productoAjustado.agregarIngrediente(tomate);
        assertEquals(12000 + 2000 + 1000, productoAjustado.getPrecio());
    }

    @Test
    void testGenerarTextoFactura()
    {
        productoAjustado.agregarIngrediente(queso);
        String texto = productoAjustado.generarTextoFactura();
        assertTrue(texto.contains("Queso"));
        assertTrue(texto.contains("2000"));
    }
}
