package uniandes.dpoo.hamburguesas.consola;

import java.io.File;
import java.util.Scanner;

import uniandes.dpoo.hamburguesas.mundo.Restaurante;
import uniandes.dpoo.hamburguesas.excepciones.*;

public class AplicacionHamburguesas
{
    private Restaurante restaurante;

    public static void main(String[] args)
    {
        AplicacionHamburguesas app = new AplicacionHamburguesas();
        app.ejecutarAplicacion();
    }

    public void ejecutarAplicacion()
    {
        restaurante = new Restaurante();
        try
        {
            restaurante.cargarInformacionRestaurante(
                new File("./data/ingredientes.txt"),
                new File("./data/menu.txt"),
                new File("./data/combos.txt")
            );
        }
        catch (Exception e)
        {
            System.out.println("Error cargando archivos: " + e.getMessage());
            return;
        }

        Scanner sc = new Scanner(System.in);
        boolean continuar = true;
        while (continuar)
        {
            System.out.println("\n=== Restaurante Hamburguesas ===");
            System.out.println("1. Ver menú");
            System.out.println("2. Iniciar pedido");
            System.out.println("3. Agregar producto al pedido");
            System.out.println("4. Cerrar pedido y guardar factura");
            System.out.println("5. Salir");
            System.out.print("Seleccione una opción: ");
            int opcion = sc.nextInt();
            sc.nextLine(); // limpiar buffer

            try
            {
                switch (opcion)
                {
                    case 1:
                        mostrarMenu();
                        break;
                    case 2:
                        iniciarPedido(sc);
                        break;
                    case 3:
                        agregarProductoAlPedido(sc);
                        break;
                    case 4:
                        cerrarPedido();
                        break;
                    case 5:
                        continuar = false;
                        break;
                    default:
                        System.out.println("Opción inválida.");
                }
            }
            catch (Exception e)
            {
                System.out.println("Error: " + e.getMessage());
            }
        }
        sc.close();
    }

    private void mostrarMenu()
    {
        System.out.println("\nProductos:");
        restaurante.getMenuBase().forEach(p -> System.out.println("- " + p.getNombre() + " $" + p.getPrecio()));

        System.out.println("\nCombos:");
        restaurante.getMenuCombos().forEach(c -> System.out.println("- " + c.getNombre() + " $" + c.getPrecio()));
    }

    private void iniciarPedido(Scanner sc) throws YaHayUnPedidoEnCursoException
    {
        System.out.print("Nombre del cliente: ");
        String nombre = sc.nextLine();
        System.out.print("Dirección del cliente: ");
        String direccion = sc.nextLine();

        restaurante.iniciarPedido(nombre, direccion);
        System.out.println("Pedido iniciado.");
    }

    private void agregarProductoAlPedido(Scanner sc)
    {
        if (restaurante.getPedidoEnCurso() == null)
        {
            System.out.println("Debe iniciar un pedido primero.");
            return;
        }

        System.out.print("Nombre del producto a agregar: ");
        String nombreProducto = sc.nextLine();

        boolean agregado = false;
        for (var p : restaurante.getMenuBase())
        {
            if (p.getNombre().equalsIgnoreCase(nombreProducto))
            {
                restaurante.getPedidoEnCurso().agregarProducto(p);
                agregado = true;
                break;
            }
        }

        if (!agregado)
        {
            for (var c : restaurante.getMenuCombos())
            {
                if (c.getNombre().equalsIgnoreCase(nombreProducto))
                {
                    restaurante.getPedidoEnCurso().agregarProducto(c);
                    agregado = true;
                    break;
                }
            }
        }

        if (agregado)
            System.out.println("Producto agregado.");
        else
            System.out.println("Producto no encontrado.");
    }

    private void cerrarPedido() throws NoHayPedidoEnCursoException, Exception
    {
        restaurante.cerrarYGuardarPedido();
        System.out.println("Pedido cerrado y factura guardada.");
    }
}
